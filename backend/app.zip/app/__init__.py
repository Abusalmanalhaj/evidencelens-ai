"""EvidenceLens AI backend application."""
