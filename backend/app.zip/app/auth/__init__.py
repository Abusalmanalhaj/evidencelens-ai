"""Authentication utilities."""
